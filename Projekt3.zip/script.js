let loc = window.location.href;

// ***COURSES***
// Kurzusok megjelenítése
async function GetCourses() {
    let courses = '<div class="courses">';
    try {
        let response = await fetch("https://vvri.pythonanywhere.com/api/courses");
        
        if(!response.ok)
            throw new Error("Error!");

        let result = await response.json();

        for(let i = 0; i < result.length; i++) {
            courses += '<section class="course"><div class="header"><h3><a href="./index.html?course=' + result[i].id + '">' + result[i].name + '</a></h3><button class="btn" data-id=' + result[i].id + ' onclick="OpenEditingPanel(this);"><i class="fa-solid fa-pen-to-square"></i></button></div><div class="body"><p>';
            
            let students = await result[i].students;
            
            if(students != [] && students.length > 0) {
                for(let j = 0; j < students.length; j++) {
                    courses += `<span class="course-student"><a href="?student=${students[j].id}">${students[j].name}</a></span>`;
                    if(j != students.length - 1)
                        courses += ', ';
                }
            }

            courses += '</p></div></section>';
        }
    }
    catch(err) { console.log(err); }

    courses += '</div>';
    return courses;
}

// Egy kurzus megjelenítése
async function GetCourseById(courseId) {
    let course = "";

    try {
        let response = await fetch("https://vvri.pythonanywhere.com/api/courses/" + courseId);
    
        if(!response.ok)
            throw new Error("ERROR");
    
        course = await response.json();
        console.log(course.name, course.id);
    }
    catch(err) {
        console.log(err);
    }

    console.log(course.name, course.id);
    return '<div class="course-container"><h2>' + course.name + '</h2><button class="btn" data-id=' + course.id + ' onclick="OpenEditingPanel(this);"><i class="fa-solid fa-pen-to-square"></i></button></div>';
}

// Kurzus módosítása
async function ModifyCourse(courseId, newCourseName) {
    try {
        let response = await fetch("https://vvri.pythonanywhere.com/api/courses/" + courseId, {
            method: "PATCH",
            headers: { "Content-type": "application/json; charset=UTF-8" },
            body: JSON.stringify({ "name": newCourseName })
        });
        let res = await response.json();
        console.log(res);
    }
    catch(err) { console.log(err); }

    await LoadPage();
}

// Kurzusszerkesztő felület
function OpenEditingPanel(obj) {
    const editingPanel = document.createElement('div'), id = obj.getAttribute("data-id");
    editingPanel.classList.add('editing-panel');
    document.body.appendChild(editingPanel);
    

    editingPanel.innerHTML = '<div class="edit-header"><button class="btn-close">X</button></div><div class="edit-body"><div class="edit-panel-form"><div class="edit-form-input"><label for="new-course-name">Új kurzusnév:</label><input type="text" id="new-course-name" name="new-course-name"></div><button class="btn" onclick="ModifyCourse(' + id + ', document.querySelector(\'#new-course-name\').value)">Módosítás</button></div></div>';
    
    document.querySelector('.btn-close').onclick = () => document.body.removeChild(editingPanel);
}

// Új kurzus létrehozása
async function CreateCourse(courseName) {
    try {
        let response = await fetch("https://vvri.pythonanywhere.com/api/courses", {
            method: "POST",
            headers: { "Content-type": "application/json; charset=UTF-8" },
            body: JSON.stringify({ "name": courseName })
        });
        
        let result = await response.json();
        console.log(result);
    }
    catch(err) { console.log(err); }

    await LoadPage();
}
// ***STUDENTS***
// Diákok megjelenítése:
async function GetStudents() {
    let students = '<div class="students"><ul id="student-list">';
    try {
        let response = await fetch("https://vvri.pythonanywhere.com/api/students");
        let result = await response.json();

        console.log(result);
        
        for(let i = 0; i < result.length; i++)
            students += `<li class="student"><a href="?student=${result[i].id}">${result[i].name}</a></li>`;
    }
    catch(err) { console.log(err); }

    students += '</ul></div>';

    return students;
}

// Egy diák megjelenítése
async function GetStudentById(studId) {
    let student = "";

    try {
        let response = await fetch("https://vvri.pythonanywhere.com/api/students/" + studId);
    
        if(!response.ok)
            throw new Error("ERROR");
    
        student = await response.json();
        console.log(stud.name, stud.id);
    }
    catch(err) { console.log(err); }

    console.log(student.name, student.id);
    return '<div class="student-container"><h2>' + student.name + ' [' +student.id + ']</h2><button class="btn" data-id=' + student.id + ' onclick="OpenStudentEditingPanel(this);"><i class="fa-solid fa-pen-to-square"></i></button><button class="btn" id="btn-delete" data-id=' + student.id + ' onclick="OpenDeletePanel(this);"><i class="fa-solid fa-trash"></i></button></div>';
}

// Diák szerkesztő felület
function OpenStudentEditingPanel(obj) {
    const editingPanel = document.createElement('div'), id = obj.getAttribute("data-id");
    editingPanel.classList.add('editing-panel');
    document.body.appendChild(editingPanel);
    

    editingPanel.innerHTML = '<div class="edit-header"><button class="btn-close">X</button></div><div class="edit-body"><div class="edit-panel-form"><div class="edit-form-input"><label for="new-student-name">Új diáknév:</label><input type="text" id="new-student-name" name="new-student-name"></div><button class="btn" onclick="ModifyStudent(' + id + ', document.querySelector(\'#new-student-name\').value)">Módosítás</button></div></div>';
    
    document.querySelector('.btn-close').onclick = () => document.body.removeChild(editingPanel);
}

// Új diák
async function NewStudent(studentName) {
    try {
        let response = await fetch("https://vvri.pythonanywhere.com/api/students", {
            method: "POST",
            headers: { "Content-type": "application/json; charset=UTF-8" },
            body: JSON.stringify({ "name": studentName, "course_id": 1 })
        });

        if(!response.ok)
            throw new Error("Error");
        
        let result = await response.json();
        console.log(result);
    }
    catch(err) { console.log(err); }

    await LoadPage();
}

// Diák - törlés felület
function OpenDeletePanel(obj) {
    const deletePanel = document.createElement('div'), id = obj.getAttribute("data-id");
    deletePanel.classList.add('editing-panel');
    document.body.appendChild(deletePanel);

    deletePanel.innerHTML = '<div class="edit-header"><button class="btn-close">X</button></div><div class="edit-body"><button class="btn" onclick="DeleteStudent(' + id + ')">Törlés</button><button class="btn btn-close">Mégse</button></div></div>';

    document.querySelector('.btn-close').onclick = () => document.body.removeChild(deletePanel);
    document.querySelector('.btn.btn-close').onclick = () => document.body.removeChild(deletePanel);
}

// Diák törlése
async function DeleteStudent(studentId) {
    try {
        let response = await fetch("https://vvri.pythonanywhere.com/api/students/" + studentId, {
            method: "DELETE",
            headers: { "Content-type": "application/json; charset=UTF-8" }
        });

        if(!response.ok)
            throw new Error("Error!");
    }
    catch(err) { console.log(err); }

    window.location.href = "?students";
}

async function AddStudentToCourse(courseId, studentId) {
    
}

// Oldal tartalmának megjelenítése
async function LoadPage() {
    if(containsCharacter(window.location.href, '?')) {
        let url = window.location.href.split('?')[1].split('=');
        let pg = url[0], val = url[1];

        console.log(pg, val);

        // Load page
        switch(pg) {
            case 'courses':
                document.querySelector('main').innerHTML = await GetCourses();
                document.querySelector('aside').innerHTML = '<h2>Új kurzus létrehozása</h2><div id="course-creation"><label for="course-name">Kurzus neve:</label><input type="text" id="course-name" name="course-name" placeholder="Kurzus neve"><button type="submit" class="btn" id="btn-create-course">Létrehozás</button></div>';

                document.querySelector('#btn-create-course').onclick = async () => {
                    await CreateCourse(document.querySelector("#course-name").value);
                    document.querySelector('main').innerHTML = await GetCourses();
                };
                break;
            case 'course':
                //console.log("COURSE", val);
                document.querySelector('main').innerHTML = await GetCourseById(val);
                break;
            case 'students':
                document.querySelector('main').innerHTML = await GetStudents();
                document.querySelector('aside').innerHTML = '<h2>Új diák hozzáadása</h2><div id="new-student"><label for="student-name">Diák neve:</label><input type="text" id="student-name" name="student-name" placeholder="Diák neve"><label for="student-course-id">Diák kurzusa:</label><input type="text" id="student-course-id" name="student-course-id" placeholder="Diák kurzusa"><button type="submit" class="btn" id="btn-new-student">Hozzáadás</button></div>';
                
                document.querySelector('#btn-new-student').onclick = async () => {
                    await NewStudent(document.querySelector("#student-name").value);
                    document.querySelector('main').innerHTML = await GetStudents();
                };
                break;
            case 'student':
                document.querySelector('main').innerHTML = await GetStudentById(val);
                break;
            case '404':
                document.querySelector('main').innerHTML = "<h1>404</h1>";
                break;
            default:
                window.location.href = "?404";
                break;
        }
    }
    else
        window.location.href = "?courses";
}


window.onload = LoadPage();
document.querySelector('.btn-refresh').onclick = async () => await LoadPage();


function containsCharacter(text, char) {
    if(char.length > 2)
        char = char[0];

    for(let i = 0; i < text.length; i++) {
        if(text[i] === char)
            return true;
    }
    return false;
}
