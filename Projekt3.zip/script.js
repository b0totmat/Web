let loc = window.location.href;

// ***COURSES***
// Kurzusok megjelenítése
async function GetCourses() {
    let courses = '<div class="courses">';
    try {
        let response = await fetch("https://vvri.pythonanywhere.com/api/courses");
        
        if(!response.ok)
            throw new Error("Error!");

        let result = await response.json();

        for(let i = 0; i < result.length; i++) {
            let cName = result[i].name;
            if(cName.length > 20)
                cName = `${cName.substring(0, 20).trim()}...`;
            courses += '<section class="course"><div class="header"><h3><a href="./index.html?course=' + result[i].id + '" title="' + result[i].name + '">' + cName + '</a></h3><button class="btn" data-id=' + result[i].id + ' onclick="OpenEditingPanel(this);"><i class="fa-solid fa-pen-to-square"></i></button></div><div class="body"><p>';
            
            let students = await result[i].students;
            
            if(students != [] && students.length > 0) {
                for(let j = 0; j < students.length; j++) {
                    courses += `<span class="course-student"><a href="?student=${students[j].id}">${students[j].name}</a></span>`;
                    if(j != students.length - 1)
                        courses += ', ';
                }
            }

            courses += '</p></div></section>';
        }
    }
    catch(err) { console.log(err); }

    courses += '</div>';
    return courses;
}

// Egy kurzus megjelenítése
async function GetCourseById(courseId) {
    let course = "";

    try {
        let response = await fetch("https://vvri.pythonanywhere.com/api/courses/" + courseId);
    
        if(!response.ok)
            throw new Error("ERROR");
    
        course = await response.json();
        console.log(course.name, course.id);
    }
    catch(err) {
        console.log(err);
    }

    console.log(course.name, course.id);
    return '<div class="course-container"><h2>' + course.name + '</h2><button class="btn" data-id=' + course.id + ' onclick="OpenEditingPanel(this);"><i class="fa-solid fa-pen-to-square"></i></button></div>';
}

// Kurzus módosítása
async function ModifyCourse(courseId, newCourseName) {
    try {
        let response = await fetch("https://vvri.pythonanywhere.com/api/courses/" + courseId, {
            method: "PATCH",
            headers: { "Content-type": "application/json; charset=UTF-8" },
            body: JSON.stringify({ "name": newCourseName })
        });
        let res = await response.json();
        console.log(res);
    }
    catch(err) { console.log(err); }

    await LoadPage();
}

// Kurzusszerkesztő felület
function OpenEditingPanel(obj) {
    const editingPanel = document.createElement('div'), id = obj.getAttribute("data-id");
    editingPanel.classList.add('editing-panel');
    document.body.appendChild(editingPanel);
    

    editingPanel.innerHTML = '<div class="edit-header"><button class="btn-close"><i class="fa-solid fa-xmark"></i></button></div><div class="edit-body"><div class="edit-panel-form"><div class="edit-form-input"><label for="new-course-name">Új kurzusnév:</label><input type="text" id="new-course-name" name="new-course-name"></div><button class="btn" onclick="ModifyCourse(' + id + ', document.querySelector(\'#new-course-name\').value)">Módosítás</button></div></div>';
    
    document.querySelector('.btn-close').onclick = () => document.body.removeChild(editingPanel);
}

// Új kurzus létrehozása
async function CreateCourse(courseName) {
    try {
        let response = await fetch("https://vvri.pythonanywhere.com/api/courses", {
            method: "POST",
            headers: { "Content-type": "application/json; charset=UTF-8" },
            body: JSON.stringify({ "name": courseName })
        });
        
        let result = await response.json();
        console.log(result);
    }
    catch(err) { console.log(err); }

    await LoadPage();
}

async function SearchCourse(courseName) {
    let courseId = null;
    try {
        let response = await fetch("https://vvri.pythonanywhere.com/api/courses");
        if(!response.ok)
            throw new Error("Error");
        
        let courses = await response.json();

        for(let i = 0; i < courses.length; i++) {
            if(courses[i].name === courseName)
                courseId = courses[i].id;
        }
    }
    catch(err) { console.log(err); }

    window.location.href = '?course=' + courseId;
}

// ***STUDENTS***
// Diákok megjelenítése:
async function GetStudents() {
    let students = '<div class="students"><ul id="student-list">';
    try {
        let response = await fetch("https://vvri.pythonanywhere.com/api/students");
        let result = await response.json();

        console.log(result);
        
        for(let i = 0; i < result.length; i++)
            students += `<li class="student"><a href="?student=${result[i].id}">${result[i].name}</a></li>`;
    }
    catch(err) { console.log(err); }

    students += '</ul></div>';

    return students;
}

// Egy diák megjelenítése
async function GetStudentById(studId) {
    let student = "";

    try {
        let response = await fetch("https://vvri.pythonanywhere.com/api/students/" + studId);
    
        if(!response.ok)
            throw new Error("ERROR");
    
        student = await response.json();
        console.log(student.name, student.id);
    }
    catch(err) { console.log(err); }

    console.log(student.name, student.id);
    return '<div class="student-container"><h2>' + student.name + ' [' +student.id + ']</h2><button class="btn" data-id=' + student.id + ' onclick="OpenStudentEditingPanel(this);"><i class="fa-solid fa-pen-to-square"></i></button><button class="btn" id="btn-delete" data-id=' + student.id + ' onclick="OpenDeletePanel(this);"><i class="fa-solid fa-trash"></i></button></div>';
}

// Diák szerkesztő felület
async function OpenStudentEditingPanel(obj) {
    const editingPanel = document.createElement('div'), id = obj.getAttribute("data-id");
    editingPanel.classList.add('editing-panel');
    document.body.appendChild(editingPanel);
    let options = '', studName = '';
    
    try {
        let res1 = await fetch("https://vvri.pythonanywhere.com/api/courses"),
            res2 = await fetch("https://vvri.pythonanywhere.com/api/students/" + id);

        if(!res1.ok)
            throw new Error("Error");
        if(!res2.ok)
            throw new Error("Error");

        let courses = await res1.json();
        console.log(courses);
        for(let i = 0; i < courses.length; i++)
            options += '<option value=' + courses[i].id + '>' + courses[i].name + '</option>';

        let student = await res2.json();
        studName = await student.name;
    }
    catch(err) { console.log(err); }

    editingPanel.innerHTML = '<div class="edit-header"><button class="btn-close"><i class="fa-solid fa-xmark"></i></button></div><div class="edit-body"><div class="edit-panel-form"><div class="edit-form-input"><label for="new-student-name">Új diáknév:</label><input type="text" id="new-student-name" name="new-student-name" value=' + studName + '><select>' + options + '</select></div><button class="btn" onclick="ModifyStudent(document.querySelector(\'select\').value, ' + id + ', document.querySelector(\'#new-student-name\').value)">Módosítás</button></div></div>';
    
    document.querySelector('.btn-close').onclick = () => document.body.removeChild(editingPanel);
}

// Új diák
async function NewStudent(studentName, courseId) {
    try {
        let response = await fetch("https://vvri.pythonanywhere.com/api/students", {
            method: "POST",
            headers: { "Content-type": "application/json; charset=UTF-8" },
            body: JSON.stringify({
                "name": studentName,
                "course_id": courseId
            })
        });

        if(!response.ok)
            throw new Error("Error");
        
        let result = await response.json();
        console.log(result);
    }
    catch(err) { console.log(err); }

    await LoadPage();
}

// Diák - törlés felület
function OpenDeletePanel(obj) {
    const deletePanel = document.createElement('div'), id = obj.getAttribute("data-id");
    deletePanel.classList.add('editing-panel');
    document.body.appendChild(deletePanel);

    deletePanel.innerHTML = '<div class="edit-header"><button class="btn-close"><i class="fa-solid fa-xmark"></i></button></div><div class="edit-body"><button class="btn" onclick="DeleteStudent(' + id + ')">Törlés</button><button class="btn btn-close">Mégse</button></div></div>';

    document.querySelector('.btn-close').onclick = () => document.body.removeChild(deletePanel);
    document.querySelector('.btn.btn-close').onclick = () => document.body.removeChild(deletePanel);
}

// Diák törlése
async function DeleteStudent(studentId) {
    try {
        let response = await fetch("https://vvri.pythonanywhere.com/api/students/" + studentId, {
            method: "DELETE",
            headers: { "Content-type": "application/json; charset=UTF-8" }
        });

        if(!response.ok)
            throw new Error("Error!");
    }
    catch(err) { console.log(err); }

    window.location.href = "?students";
}

// Diák módosítása
async function ModifyStudent(courseId, studentId, newName) {
    try {
        let response = await fetch("https://vvri.pythonanywhere.com/api/students/" + studentId, {
            method: "PUT",
            headers: { "Content-type": "application/json; charset=UTF-8" },
            body: JSON.stringify({
                "name": newName,
                "course_id": courseId
            })
        });

        if(!response.ok)
            throw new Error("Error");

        console.log(await response.json());
    }
    catch(err) { console.log(err); }

    await LoadPage();
}

// Oldal tartalmának megjelenítése
async function LoadPage() {
    if(containsCharacter(window.location.href, '?')) {
        let url = window.location.href.split('?')[1].split('=');
        let pg = url[0], val = url[1];

        console.log(pg, val);

        // Load page
        switch(pg) {
            case 'courses':
                document.querySelector('main').innerHTML = await GetCourses();
                document.querySelector('aside').innerHTML = '<h2>Új kurzus létrehozása</h2><div id="course-creation"><label for="course-name">Kurzus neve:</label><input type="text" id="course-name" name="course-name" placeholder="Kurzus neve"><button type="submit" class="btn" id="btn-create-course">Létrehozás</button></div>';

                document.querySelector('#btn-create-course').onclick = async () => {
                    await CreateCourse(document.querySelector("#course-name").value);
                    document.querySelector('main').innerHTML = await GetCourses();
                };

                const searchBar = document.createElement('div');
                searchBar.classList.add('search-bar');
                searchBar.innerHTML = '<input tpye="text" id="course-search" name="course-search" placeholder="Kurzus keresése"><button class="btn" id="btn-search" onclick="SearchCourse(document.querySelector(\'#course-search\').value);"><i class="fa-solid fa-magnifying-glass"></i></button>';
                document.querySelector('header').insertBefore(searchBar, document.querySelector('.btn.btn-refresh'));
                break;
            case 'course':
                //console.log("COURSE", val);
                document.querySelector('main').innerHTML = await GetCourseById(val);
                document.querySelector('aside').style.display = "none";
                break;
            case 'students':
                document.querySelector('main').innerHTML = await GetStudents();
                document.querySelector('aside').innerHTML = '<h2>Új diák hozzáadása</h2><div id="new-student"><label for="student-name">Diák neve:</label><input type="text" id="student-name" name="student-name" placeholder="Diák neve"><label for="student-course-id">Diák kurzusa:</label><input type="text" id="student-course-id" name="student-course-id" placeholder="Diák kurzusa"><button type="submit" class="btn" id="btn-new-student">Hozzáadás</button></div>';
                
                document.querySelector('#btn-new-student').onclick = async () => {
                    await NewStudent(document.querySelector("#student-name").value, document.querySelector("#student-course-id").value);
                    document.querySelector('main').innerHTML = await GetStudents();
                };
                break;
            case 'student':
                document.querySelector('main').innerHTML = await GetStudentById(val);
                document.querySelector('aside').style.display = "none";
                break;
            case '404':
                document.querySelector('main').innerHTML = "<h1 id=\"h-404\">404</h1>";
                document.querySelector('aside').style.display = "none";
                break;
            default:
                window.location.href = "?404";
                break;
        }
    }
    else
        window.location.href = "?courses";
}


window.onload = LoadPage();
document.querySelector('.btn-refresh').onclick = async () => await LoadPage();


function containsCharacter(text, char) {
    if(char.length > 2)
        char = char[0];

    for(let i = 0; i < text.length; i++) {
        if(text[i] === char)
            return true;
    }
    return false;
}
